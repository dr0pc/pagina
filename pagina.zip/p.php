<html>
<body>

<?php 
if ($enviar) {
   // process form
   $link = mysql_connect('localhost', 'root','');
   mysql_select_db("pagina",$link) or die ("no se puede conectar con la base de datos");
   $sql = "INSERT INTO users VALUES ('', 'prueba', 'prueba')";
   $result = mysql_query($sql);
   echo "¡Gracias! Hemos recibido sus datos.\n"; 
}else{
?> 



<form>
Nombre   :<input type="Text" name="nombre"><br>
Dirección:<input type="Text" name="direccion"><br>
Teléfono :<input type="Text" name="telefono"><br>
<input type="Submit" name="enviar" value="Aceptar información">
</form>


<?php 
} //end if 
?> 

</body>
</html>
