<!DOCTYPE html> 
<html>
<head>
  <title>CVE-2017</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
</head>

<body>
  <div id="main">
    <header>
	  <div id="welcome">
	    <h2>CVE - 2017</h2>
	  </div><!--close welcome-->			  	
	</header>
	
	<nav>
	  <div id="menubar">
        <ul id="nav">
          <li><a href="index.html">Home</a></li>
          <li class="current"><a href="cvelist.html">CVE-LIST</a></li>
          <li><a href="cveadd.html">CVE-ADD</a></li>
          
          
        </ul>
      </div><!--close menubar-->	
    </nav>	
    
	<div id="site_content">		

      <div class="slideshow">
	    <ul class="slideshow">
          <li class="show"><img width="940" height="300" src="images/home_1.jpg"  /></li>
          <li><img width="940" height="300" src="images/home_2.jpg"  /></li>
        </ul> 
	  </div><!--close slideshow-->	
	
	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
            
          </div><!--close sidebar_item--> 
        </div><!--close sidebar-->     		
		<div class="sidebar">
          <div class="sidebar_item">
            <h3>CVE-2017-0144</h3>
            <p> A large ransomware campaign has been observed since Friday, May 12th, 2017.  The payload
delivered is a variant of ransomware malware called
WannaCry
. It appears to infect computers
through a recent SMB vulnerability in Microsoft Windows operating system </p>
		  </div><!--close sidebar_item--> 
        </div><!--close sidebar-->
		<div class="sidebar">
          <div class="sidebar_item">
            <h3>CVE-2008-4250</h3>
            <p>his is a remote code execution vulnerability. An attacker who successfully exploited this vulnerability could take complete control of an affected system remotely. On Microsoft Windows 2000-based, Windows XP-based, and Windows Server 2003-based systems, an attacker could exploit this vulnerability over RPC without authentication and could run arbitrary code. If an exploit attempt fails, this could also lead to a crash in Svchost.exe. If the crash in Svchost.exe occurs, the Server service will be affected. The Server service provides file, print, and named pipe sharing over the network.</p>         
		  </div><!--close sidebar_item--> 
        </div><!--close sidebar-->  		
        <div class="sidebar">
          <div class="sidebar_item">
            <h2>Contact</h2>
            
            <p>Email: <a href="mailto:6luiscarret@gmail.com">6luiscarret@gmail.com</a></p>
          </div><!--close sidebar_item--> 
        </div><!--close sidebar-->
       </div><!--close sidebar_container-->	
	
	  <div id="content">
        <div class="content_item">




		<br>
		<br>
		<div style="text-align:center;">

		  <h1>CVE's En Pleno 2017</h1> </div>
			<p> <?php
                        $con = mysql_connect('localhost','root','');
                        mysql_select_db("cve",$con) or die ("no se puede conectar con la base de datos");
                ?>
		<div style="text-align:center;">
                <table border="2"style="margin: 0 auto; align=center" bordercolor="#B40404" >
                        <tr>
                                <td colspan="4"> LISTADO DE CVE's</td>
                        </tr>

                        <tr>
                                <td>ID_CVE</td>
                                <td>Date_Entry_Created</td>
				<td>References</td>
				<td>Description</td>
                        </tr>

                        <?php
                                $consulta = mysql_query(" select * from cves ");
                                while($row = mysql_fetch_array($consulta)) { ?>    

                                        <tr>
                        <td> <?php echo $row["cve"];  ?> </td>
                        <td> <?php echo $row["data"];  ?> </td>
                        <td> <?php echo $row["referen"];  ?> </td>
			<td> <?php echo $row["description"]; ?> </td>
 </p>   				  

                                        </tr>
                        <?php
                        }
                        ?>

                </table>
			</div>








		  <div class="content_imagetext">
		    <div class="content_image">
		     
	        </div>
		    
		  </div><!--close content_imagetext-->		  
		  <div class="content_container">
		    
		  
		     
		    </div><!--close button_small-->
		  </div><!--close content_container-->
          <div class="content_container">
		             
		  	
		   
		    </div><!--close button_small-->		  
		  </div><!--close content_container-->			  
		</div><!--close content_item-->
      </div><!--close content-->   
	
	</div><!--close site_content-->  	
  
    <footer>
	 
	 
    </footer> 
  
  </div><!--close main-->
  
  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  
</body>
</html>
